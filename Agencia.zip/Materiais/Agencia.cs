﻿namespace Materiais;
public class Agencia
{
    public int Numero { get; set; }
}


public class Material
{
    public int Id { get; set; }
    public string Descricao { get; set; }
}